import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';

import { PlanBenefitsRoutingModule } from './plan-benefits-routing.module';
import { PlanBenefitsComponent } from './components/plan-benefits/plan-benefits.component';

@NgModule({
  declarations: [PlanBenefitsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    PlanBenefitsRoutingModule
  ],
  exports: [PlanBenefitsComponent]
})
export class PlanBenefitsModule { }
