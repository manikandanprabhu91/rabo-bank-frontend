export interface Theme {
    name: string;
    properties: any;
}

export const base: Theme  = {
    name: "base",
    properties: {
"--foreground-default":"#0809A",
"--foreground-primary":"#41474D",
"--foreground-secondary":"#797C80",
"--foreground-tertiary":"#F4FAFF",
"--background-default":"#41474D",
"--background-primary":"#F4FAFF",
"--background-secondary":"#A3B9CC",
"--background-tertiary":"#5C7D99",
"--button-default":"#5DFCBB",
"--button-primary":"#24B286",
"--button-secondary":"#B2FFE7",
"--button-tertiary":"#A3B9CC",
"--error-default":"#EF3E36",
"--error-primary":"#800600",
"--error-secondary":"#FFCECC",
"--error-tertiary":"#5C7D99",
    }
};