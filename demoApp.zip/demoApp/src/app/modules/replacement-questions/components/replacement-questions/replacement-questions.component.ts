import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { ReplacementQuestionsService } from './../../services/replacement-questions.service';
import { PrescribedMedicationsService } from './../../../prescribed-medications/services/prescribed-medications.service';
import { PlanBenifitsService } from './../../../plan-benefits/services/plan-benifits.service';

@Component({
  selector: 'app-replacement-questions',
  templateUrl: './replacement-questions.component.html',
  styleUrls: ['./replacement-questions.component.scss']
})
export class ReplacementQuestionsComponent implements OnInit {
  openReplaceQuesAccordion: boolean;
  customClass = 'customClass';
  replacementQuestionsForm: FormGroup;
  otherInsuranceForm: FormGroup;
  addMoreMed: boolean = false;

  constructor(private fb: FormBuilder,
    private replacementQuestionsService: ReplacementQuestionsService,
    private prescribedMedicationsService: PrescribedMedicationsService,
    private planBenifitsService: PlanBenifitsService) { }

  ngOnInit() {
      this.replacementQuestionsService.data.subscribe(
        res => this.openReplaceQuesAccordion = res
      )

      this.planBenifitsService.data2.subscribe(
        res => this.openReplaceQuesAccordion = res
      )

      this.replacementQuestionsForm = this.fb.group({
        insuranceInForce: [],
        insuranceDetails: this.fb.array([
          this.fb.group({
            typeOfCoverage: [],
            policyNumber: [],
            company: []
          }),
          this.fb.group({
            typeOfCoverage: [],
            policyNumber: [],
            company: []
          })
        ])
      })

      this.otherInsuranceForm = this.fb.group({
        insuranceInForce: [],
          otherInsuranceDetails: this.fb.group({
            typeOfCoverage: [],
            policyNumber: [],
            company: []
          })
      })
    }

  addMoremedications() {
    this.addMoreMed = true;
  }

  removeMoremedications() {
    this.addMoreMed = false;
  }

  accOpenChange(event: boolean) {
    if(event == true) {
        this.openReplaceQuesAccordion = true;
    } else {
        this.openReplaceQuesAccordion = false;
    }
  }

  gotoPrevious() {
    this.replacementQuestionsService.updatedreplaceQuesAccoState(true);
  }

  gotoNext() {
    this.planBenifitsService.updatedplanBenefaccoShowHideAccoState(true);
    this.openReplaceQuesAccordion = !this.openReplaceQuesAccordion;
  }

}
