declare var window: any;

export class DynamicEnvironment {
  public getEnvironment() {
    return window.config.environment;
  }

  public getResturl() {
    console.log('REST_URL::::::', window.config.REST_URL);
    return window.config.REST_URL;
  }
}
