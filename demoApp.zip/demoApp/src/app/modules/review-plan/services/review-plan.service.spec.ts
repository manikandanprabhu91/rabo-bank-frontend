import { TestBed } from '@angular/core/testing';

import { ReviewPlanService } from './review-plan.service';

describe('ReviewPlanService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReviewPlanService = TestBed.get(ReviewPlanService);
    expect(service).toBeTruthy();
  });
});
