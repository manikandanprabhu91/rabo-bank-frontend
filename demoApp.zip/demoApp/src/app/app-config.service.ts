import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
declare var window: any;

@Injectable({
  providedIn: 'root'
})
export class AppConfigService {

  private appConfig;

  constructor(private http: HttpClient) { }

  loadAppConfig() {
    let url = new URL(window.location.href);
    console.log('Loading app configurations from:::::' + url);
    let configurl;
    if (url.hostname.indexOf('localhost') > -1) {
      console.log('Hostname:::::' + url.hostname);
      configurl = '/app-config/app-config.json';
    } else if (url.hostname.indexOf('dev') > -1) {
      console.log('Hostname:::::' + url.hostname);
      configurl = '/app-config/dev-app-config.json';
    } else if (url.hostname.indexOf('qa') > -1) {
      console.log('Hostname:::::' + url.hostname);
      configurl = '/app-config/qa-app-config.json';
    } else {
      configurl = url + '/app-config/prod-app-config.json';
    }
    /*configurl = '/config/app-local.config.json';*/
    return this.http.get(configurl)
      .toPromise()
      .then(data => {
        window.config = data;
        this.appConfig = data;
        console.log('appConfig data::::::', this.appConfig);
        return;
      });
  }

  getConfig() {
    return this.appConfig;
  }
}
