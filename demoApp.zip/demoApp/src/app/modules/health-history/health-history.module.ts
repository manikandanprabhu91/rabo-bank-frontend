import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';

import { HealthHistoryRoutingModule } from './health-history-routing.module';
import { HealthHistoryComponent } from './components/health-history/health-history.component';

@NgModule({
  declarations: [ HealthHistoryComponent ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    HealthHistoryRoutingModule
  ],
  exports: [ HealthHistoryComponent ]
})
export class HealthHistoryModule { }
