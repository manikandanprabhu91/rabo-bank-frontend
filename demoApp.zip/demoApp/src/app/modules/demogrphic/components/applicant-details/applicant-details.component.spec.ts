import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule, AccordionComponent } from 'ngx-bootstrap/accordion';
import { ApplicantDetailsComponent } from './applicant-details.component';
describe('ApplicantDetailsComponent', () => {
  let component: ApplicantDetailsComponent;
  let fixture: ComponentFixture<ApplicantDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicantDetailsComponent ],
      imports: [ 
        BrowserAnimationsModule,
        ButtonsModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AccordionModule.forRoot(),
        FormsModule,
        ReactiveFormsModule
     ],
     providers: [AccordionComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicantDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

it('Begin enrollment form should be invalid', () => {
    expect(component.beginEnrollmentForm.valid).toBeFalsy();
})

 it('state should be valid', () => {
    let errors = {};
    let state = component.beginEnrollmentForm.get('state'); 
    expect(state.valid).toBeFalsy();

    errors = state.errors || {}
    expect(errors['required']).toBeTruthy();

    state.setValue('Florida');
    errors = state.errors || {}
    expect(errors['required']).toBeFalsy();
})

it('age should be valid', () => {
  let errors = {};
  let age = component.beginEnrollmentForm.get('age'); 
  expect(age.valid).toBeFalsy();

  errors = age.errors || {}
  expect(errors['required']).toBeTruthy();

  age.setValue('30');
  errors = age.errors || {}
  expect(errors['required']).toBeFalsy();
})

it('prefix should be valid', () => {
    let errors = {};
    let prefix = component.beginEnrollmentForm.get('prefix'); 
    expect(prefix.valid).toBeFalsy();

    errors = prefix.errors || {}
    expect(errors['required']).toBeTruthy();

    prefix.setValue('Mr');
    errors = prefix.errors || {}
    expect(errors['required']).toBeFalsy();
})

it('middileInitial should be valid', () => {
  let errors = {};
  let middileInitial = component.beginEnrollmentForm.get('middileInitial'); 
  expect(middileInitial.valid).toBeTruthy();
})

it('Begin Enrollment Form should be valid', () => {
    let state = component.beginEnrollmentForm.get('state');
    state.setValue('Florida');
    let DOB = component.beginEnrollmentForm.get('DOB');
    DOB.setValue('05/01/1989');
    let prefix = component.beginEnrollmentForm.get('prefix');
    prefix.setValue('Mr');
    let age = component.beginEnrollmentForm.get('age');
    age.setValue('30');
    let firstName = component.beginEnrollmentForm.get('firstName'); 
    firstName.setValue('John');
    let middileInitial = component.beginEnrollmentForm.get('middileInitial'); 
    middileInitial.setValue('S');
    let lastName = component.beginEnrollmentForm.get('lastName'); 
    lastName.setValue('Doe');
    let address1 = component.beginEnrollmentForm.get('address1'); 
    address1.setValue('address1');
    let address2 = component.beginEnrollmentForm.get('address2'); 
    address2.setValue('address2');
    let phoneNumber = component.beginEnrollmentForm.get('phoneNumber'); 
    phoneNumber.setValue('1234567890');
    let city = component.beginEnrollmentForm.get('city'); 
    city.setValue('chennai');
    let zip = component.beginEnrollmentForm.get('zip'); 
    zip.setValue('60000');
    let email = component.beginEnrollmentForm.get('email'); 
    email.setValue('test@gmail.com');
    let gender = component.beginEnrollmentForm.get('gender'); 
    gender.setValue('Male');
    let mailingAddress = component.beginEnrollmentForm.get('mailingAddress'); 
    mailingAddress.setValue('yes');

    expect(component.beginEnrollmentForm.valid).toBeTruthy();
 })

 it('Add address form should be invalid', () => {
  expect(component.addAddressForm.valid).toBeFalsy();
 })

 it('addAddress method should call', ()=> {
  component.addAddress();
  component.isAddressAdded = true;
})
 
it('Begin Enrollment Form should be valid', () => {
  let address1 = component.addAddressForm.get('address1'); 
  address1.setValue('address1');
  let address2 = component.addAddressForm.get('address2'); 
  address2.setValue('address2');
  let city = component.addAddressForm.get('city'); 
  city.setValue('chennai');
  let zip = component.addAddressForm.get('zip'); 
  zip.setValue('60000');
  expect(component.addAddressForm.valid).toBeTruthy();
})

it('removeAddress method should call', ()=> {
  component.removeAddress();
  component.addAddressForm.reset();
  component.isAddressAdded = false;
})

it('accOpenChange function should call', () => {
   component.accOpenChange(true);
   component.openBeginEnrolAccordion = true;
   component.accOpenChange(false);
   component.openBeginEnrolAccordion = false;
})


it('gotoPlanEligibility function should call', () => {
  component.gotoPlanEligibility();
  component.openBeginEnrolAccordion = true;
  component.gotoPlanEligibility();
  component.openBeginEnrolAccordion = false;
})

});


