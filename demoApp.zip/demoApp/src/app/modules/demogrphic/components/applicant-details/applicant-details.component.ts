import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ApplicantDetailsService } from './../../services/applicant-details.service';
import { PlanEligibilityService } from './../../../plan-eligibility/services/plan-eligibility.service';
// import { SocialSecurityMaskPipe } from './../../../../application-pipes/application-pipes.module';
import { Subscription } from 'rxjs';
import { HttpClientService } from './../../../../core/http/http-client.service';

import { RateQuotePlanDataService } from './../../../../shared/services/rate-quote-plan-data.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-applicant-details',
  templateUrl: './applicant-details.component.html',
  styleUrls: ['./applicant-details.component.scss']
})

export class ApplicantDetailsComponent implements OnInit, OnDestroy {

  // selectedState = 'PA';
  // selectedDOB = new Date('07/30/1954');
  // selectedEffectiveDate = new Date('08/01/2019');

  selectedState: string;
  selectedDOB: Date;
  selectedEffectiveDate: Date;
  isReadOnlyField = true;
  selectedDoBChanged = false;
  socialSecurityId: string;
  maskSocialSecurity = true;
  maskConfirmSocialSecurity = true;
  formValue;

  bsModalRef: BsModalRef;

  toggleState;
  toggle;

  constructor(private fb: FormBuilder,
              private applicantDetailsService: ApplicantDetailsService,
              private planEligibilityService: PlanEligibilityService,
              private http: HttpClientService,
              private rateQuotePlanDataService: RateQuotePlanDataService,
              private modalService: BsModalService) { }

  beginEnrollmentForm: FormGroup;
  addAddressForm: FormGroup;
  healthHistoryForm: FormGroup;
  physicianInfoForm: FormGroup;
  customClass = 'customClass';
  isOpen  = true;
  openBeginEnrolAccordion  = true;
  isAddressAdded  = false;
  currentAge: number;
  private planEligibilitySubscription: Subscription;
  beginEnrollmentJSON: any;
  
  countries = [
    { 
      id: 1,
      cities:  'NC'
    },
  {
    id: 2, cities: 'PA'
  }
  ];

  prefixes = [{
    id: 1, prefixType:  'Mr'
  },
  {
    id: 2, prefixType: 'Ms'
  },
  {
    id: 3,  prefixType: 'Mrs'
  },
  {
    id: 4,  prefixType: 'Dr'
  },
  ];

  suffixes = [{
    id: 1, suffixType:  'Jr'
  },
  {
    id: 2, suffixType: 'Sr'
  },
  {
    id: 3,  suffixType: 'II'
  },
  {
    id: 4,  suffixType: 'III'
  },
  ];

  ngOnInit() {

    //console.log(navigator.appCodeName);
    //console.log(navigator.appVersion);

    this.beginEnrollmentJSON = {
        "rateQuoteId": 51558,
        "agentGUID": 10074727,
        "applicantDetails": {
          "applicant_A": {
            "applicantFirstName": "APPLICANT",
            "applicantMiddleName": "",
            "legalResidentInd": "Y",
            "applicantLastName": "A",
            "applicantDob": "06/01/1954",
            "applicantState": "Florida",
            "applicantAddress1": "",
            "applicantAddress2": "",
            "applicantPhoneNumber": "",
            "applicantCity": "",
            "applicantZip": "",
            "applicantEmail": "",
            "applicantGender": "",
            "applicantDiffMailingAddress": "",
            "applicantSecondaryMailingAddress": {
              "applicantAddress1": "",
              "applicantAddress2": "",
              "applicantCity": "",
              "applicantZip": ""
            },
            "productNames": [
              "Medicare Supplement"
            ]
          }
        },
        "channel": "D-spa",
        "browserName": "Chrome",
        "browserVersion": "75"
    }
    
    // this.http.get('http://localhost/web_api/').subscribe(
    //    data2 => console.log('data from service', data2)
    // )

    this.planEligibilitySubscription = this.planEligibilityService.data.subscribe(
      data => this.openBeginEnrolAccordion = data
    )

    this.populateQuoteInputFields();

    console.log('Selected: ' + this.selectedState);
    console.log('Selected: ' + this.selectedDOB);

    this.beginEnrollmentForm = this.fb.group({
      state: [''],
      DOB: ['', [Validators.required, this.forbiddenDoBValidator]],
      age: [''],
      effectiveDate: ['', [Validators.required, this.forbiddenEffectiveDateValidator]],
      prefix: [''],
      firstName: ['', [Validators.required, Validators.maxLength(28)]],
      middileInitial: [''],
      lastName: ['', [Validators.required, Validators.maxLength(15)]],
      suffix: [''],
      ssn: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]],
      confirmSSN: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]],
      address1: ['', Validators.required],
      address2: [''],
      phoneNumber: [''],
      city: ['', Validators.required],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      email: ['', Validators.email],
      gender: ['', Validators.required],
      mailingAddress: ['', Validators.required]
    }, {validator: this.inputMustMatch('ssn', 'confirmSSN')} );

    this.populateAge(this.selectedDOB.valueOf());

    this.beginEnrollmentForm.get('DOB').valueChanges.subscribe(
      data => {
        this.populateAge(data);
        //this.openModalWithComponent();
      }
    )

    this.beginEnrollmentForm.get('effectiveDate').valueChanges.subscribe(
      data => {
        this.updateEffectiveDate(data);
        //this.openModalWithComponent();
      }
    )

    this.addAddressForm = this.fb.group({
      address1: ['', Validators.required],
      address2: [''],
      city: ['', Validators.required],
      zip: ['', [Validators.required, Validators.maxLength(5)]]
    })
  }

  inputMustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        // console.log('Validate match');
        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            // return if another validator has already found an error on the matchingControl
            return;
        }

        // set error on matchingControl if validation fails
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ mustMatch: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
  }

  socialSecurityMatch(formControl: AbstractControl): {invalid: boolean} {
    if (formControl.get('ssn').value !== formControl.get('confirmSSN').value) {
      return {invalid: true};
    }
  }

  forbiddenDoBValidator(control: AbstractControl) {

    if (control.errors && !control.errors.minAgeNotMeet) {
      // return if another validator has already found an error on the matchingControl
      return;
    }
    const dob = new Date(control.value);
    const todayDate = new Date();
    let age = todayDate.getFullYear() - dob.getFullYear();
    if (age < 0) {
      age = 0;
    } else {
      const month = todayDate.getMonth() - dob.getMonth();
      if (month < 0 || (month === 0 && todayDate.getDate() < dob.getDate())) {
          age = age - 1;
      }
    }
    if (age < 18) {
      return { minAgeNotMeet: true }
    } else {
      return null;
    }
  }

  forbiddenEffectiveDateValidator(control: AbstractControl) {
    if (!control.value) {
      // console.log('empty String');
      return null;
    }
    const effectiveDate = new Date(control.value);
    //console.log(effectiveDate);
    const todayDate = new Date();
    const dayDifference =  Math.ceil((effectiveDate.valueOf() - todayDate.valueOf()) / (24 * 60 * 60 * 1000));
    //console.log('Day difference: ' + dayDifference);
    if (dayDifference > 90) {
      return { maxEffectiveDateNotMeet: true }
    } else if (dayDifference < 0) {
      return { minEffectiveDateNotMeet: true }
    } else {
      return null;
    }
  }

  calculateAge(dob: Date): number{
    const todayDate = new Date();
    let age = todayDate.getFullYear() - dob.getFullYear();
    if (age < 0) {
      age = 0;
    } else {
      const month = todayDate.getMonth() - dob.getMonth();
      if (month < 0 || (month === 0 && todayDate.getDate() < dob.getDate())) {
          age = age - 1;
      }
    }
    return age;
  }

  populateQuoteInputFields() {
    if (sessionStorage.getItem('quoteMemberState')) {
      this.rateQuotePlanDataService.changeState(sessionStorage.getItem('quoteMemberState'));
    }

    if (sessionStorage.getItem('quoteMemberDoB')) {
      this.rateQuotePlanDataService.changeDoB(sessionStorage.getItem('quoteMemberDoB'));
    }

    if (sessionStorage.getItem('quoteEffectiveDate')) {
      this.rateQuotePlanDataService.changeEffectiveDate(sessionStorage.getItem('quoteEffectiveDate'));
    }

    this.rateQuotePlanDataService.currentState.subscribe(state => this.selectedState = state);
    this.rateQuotePlanDataService.currentDoB.subscribe(dob => this.selectedDOB = new Date(dob));
    this.rateQuotePlanDataService.currentEffectiveDate.subscribe(effectiveDate => this.selectedEffectiveDate = new Date(effectiveDate));
  }

  populateAge(DOB: number) {
    let today = new Date();
    let birthDate = new Date(DOB);
    let age = today.getFullYear() - birthDate.getFullYear();
    let m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age = age - 1;
    }
    this.currentAge = age;
    this.beginEnrollmentForm.patchValue({
      age: this.currentAge
    });
  }

  // TO-DO Date change based on 90 day check
  updateEffectiveDate(inputDate: number){
    let inputEffectiveDate = new Date(inputDate);
    const day = inputEffectiveDate.getDate();
    const month = inputEffectiveDate.getMonth();
    const year = inputEffectiveDate.getFullYear();
    if ( day === 29 || day === 30 || day === 31) {
      inputEffectiveDate.setDate(1);
      if(month === 12) {
        inputEffectiveDate.setMonth(1);
        inputEffectiveDate.setFullYear(year + 1);
      } else {
        inputEffectiveDate.setMonth(month + 1);
      }
      this.beginEnrollmentForm.patchValue({
        effectiveDate: inputEffectiveDate
      });
      //const todayDate = new Date();
      //const dayDifference =  Math.ceil((effectiveDate.valueOf() - todayDate.valueOf()) / (24 * 60 * 60 * 1000));      
    }
    
  }

  dateFormat(str) {
  var date = new Date(str),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
  return [mnth, day, date.getFullYear()].join("/");
  }

get DOB() { return this.beginEnrollmentForm.get('DOB'); }

get age() { return this.beginEnrollmentForm.get('age'); }

get effectiveDate() { return this.beginEnrollmentForm.get('effectiveDate'); }

get gender() { return this.beginEnrollmentForm.get('gender'); }

get firstName() { return this.beginEnrollmentForm.get('firstName'); }

get lastName() { return this.beginEnrollmentForm.get('lastName'); }

get ssn() { return this.beginEnrollmentForm.get('ssn'); }

get confirmSSN() { return this.beginEnrollmentForm.get('confirmSSN'); }

get address1() { return this.beginEnrollmentForm.get('address1'); }

get phoneNumber() { return this.beginEnrollmentForm.get('phoneNumber'); }

get city() { return this.beginEnrollmentForm.get('city');}

get zip() { return this.beginEnrollmentForm.get('zip'); }

get mailingAddress() { return this.beginEnrollmentForm.get('mailingAddress'); }

get email() { return this.beginEnrollmentForm.get('email'); }

get addAddress1() { return this.addAddressForm.get('address1'); }

get addAddress2() { return this.addAddressForm.get('address2'); }

get addCity() { return this.addAddressForm.get('city'); }

get addZip() { return this.addAddressForm.get('zip'); }


addAddress(): void {
  this.isAddressAdded = true;
}

removeAddress(): void {
  this.addAddressForm.reset();
  this.isAddressAdded = false;
}

gotoPlanEligibility(): void {

  // [disabled]="(!beginEnrollmentForm.valid) ||  (isAddressAdded && !addAddressForm?.valid)"
  if ((!this.beginEnrollmentForm.valid) ||  (this.isAddressAdded && !this.addAddressForm.valid)) {
    this.markFormGroupTouched(this.beginEnrollmentForm);
    if (this.isAddressAdded){
      this.markFormGroupTouched(this.addAddressForm);
    }
    this.formValue = JSON.stringify(this.beginEnrollmentForm.value);
    return;
  }
  this.openBeginEnrolAccordion = !this.openBeginEnrolAccordion;
  this.applicantDetailsService.updatedAccoState(true);
}

  /**
   * Marks all controls in a form group as touched
   * @param formGroup - The form group to touch
   */
  private markFormGroupTouched(formGroup: FormGroup) {
    // Object.keys(formGroup.controls).map(x => formGroup.controls[x]);
    // this.beginEnrollmentForm.controls.forEach( '');
    (Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();
    });
  }

accOpenChange(event: boolean): void {
  if(event == true) {
    this.openBeginEnrolAccordion = true;
  } else {
    this.openBeginEnrolAccordion = false;
  }
}

  ngOnDestroy() {
    this.planEligibilitySubscription.unsubscribe();
  }

  openModalWithComponent() {
    /*const initialState = {
      list: [
        'Open a modal with component',
        'Pass your data',
        'Do something else',
        '...'
      ],
      title: 'Modal with component'
    };
    this.bsModalRef = this.modalService.show(ModalContentComponent, {initialState});
    this.bsModalRef.content.closeBtnName = 'Close';*/
  }

}

/* This is a component which we pass in modal
@Component({
  selector: 'modal-content',
  template: `
    <div class="modal-header">
      <h4 class="modal-title pull-left">{{title}}</h4>
      <button type="button" class="close pull-right" aria-label="Close" (click)="bsModalRef.hide()">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <ul *ngIf="list.length">
        <li *ngFor="let item of list">{{item}}</li>
      </ul>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" (click)="bsModalRef.hide()">{{closeBtnName}}</button>
    </div>
  `
}) 
export class ModalContentComponent implements OnInit {
  title: string;
  closeBtnName: string;
  list: any[] = [];
  constructor(public bsModalRef: BsModalRef) {}
  ngOnInit() {
    this.list.push('PROFIT!!!');
  }
}*/
