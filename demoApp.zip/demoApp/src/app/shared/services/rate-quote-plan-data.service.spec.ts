import { TestBed } from '@angular/core/testing';

import { RateQuotePlanDataService } from './rate-quote-plan-data.service';

describe('RateQuotePlanDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RateQuotePlanDataService = TestBed.get(RateQuotePlanDataService);
    expect(service).toBeTruthy();
  });
});
