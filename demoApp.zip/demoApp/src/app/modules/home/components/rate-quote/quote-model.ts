export class Quote {
    name: string;
    rate: string;
    tenure: string;
    desc: string;
    more: string;
    action: string;
  }