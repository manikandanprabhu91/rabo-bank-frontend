import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';

import { PaymentInformationRoutingModule } from './payment-information-routing.module';
import { PaymentInformationComponent } from './components/payment-information/payment-information.component';


@NgModule({
  declarations: [PaymentInformationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    PaymentInformationRoutingModule
  ],
  exports: [PaymentInformationComponent]
})
export class PaymentInformationModule { }
