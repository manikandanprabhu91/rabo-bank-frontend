import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-enroll',
  templateUrl: './enroll.component.html',
  styleUrls: ['./enroll.component.scss']
})

export class EnrollComponent implements OnInit {
  oneAtATime: boolean = true
  constructor() { }
  ngOnInit() {
    
  }
  
}
