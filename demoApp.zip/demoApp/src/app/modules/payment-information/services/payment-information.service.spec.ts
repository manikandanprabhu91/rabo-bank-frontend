import { TestBed } from '@angular/core/testing';

import { PaymentInformationService } from './payment-information.service';

describe('PaymentInformationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PaymentInformationService = TestBed.get(PaymentInformationService);
    expect(service).toBeTruthy();
  });
});
