import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, ValidatorFn,AbstractControl } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { HttpClientService } from './../../../../core/http/http-client.service';
import { ApplicantDetailsService } from './../../../demogrphic/services/applicant-details.service';
import { PlanEligibilityService } from './../../../plan-eligibility/services/plan-eligibility.service';
import { HealthHistoryService } from './../../../health-history/services/health-history.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-plan-eligibility',
  templateUrl: './plan-eligibility.component.html',
  styleUrls: ['./plan-eligibility.component.scss']
})
export class PlanEligibilityComponent implements OnInit, OnDestroy {
  form: FormGroup;
  ishowAccordion: boolean;
  customClass = 'customClass';
  planEligRequest: any;
  opVal:any;
  private applicantDetailsSubscription: Subscription;
  //private planEligUrl = 'https://qaapih1.aetna.com/healthcare/qapath2/at/v3/dech_enrollment/retrieveeligibilityquestions';
  public planEligUrl = '../assets/data/planEligibility.json';
  eligibilityDetails;
  elgDetResponse:any;
  primaryQuesLength: number;
  alphabets: Array<string> = ["A","B","C","D","E","F","G","H","I"];
  modalRef: BsModalRef;
  template: string = "template";
  bsModalRef: BsModalRef;
  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    private http: HttpClientService,
    private applicantDetailsService: ApplicantDetailsService,
    private planEligibilityService: PlanEligibilityService,
    private healthHistoryService: HealthHistoryService) {

  }

  ngOnInit() {
    this.applicantDetailsSubscription = this.applicantDetailsService.data.subscribe(
      data => this.ishowAccordion = data
    )
    this.healthHistoryService.data2.subscribe(
      data => this.ishowAccordion = data
    )

    this.planEligRequest = {
      "productId": "1",
      "stateCode": "AL",
      "screenName": "Plan Eligibility",
      "sectionName": "Eligibility Question",
      "planName": "",
      "riderName": "",
      "applicationType": "",
      "enrollRecordId": ""
    }

    // this.eligibilityDetails = this.http.post(this.planEligUrl,this.planEligRequest).subscribe((res) => {
    //   this.elgDetResponse = res && res.questions;
    //   this.primaryQuesLength = res.questions.length;
    //   this.planEligibilityRes(res.questions);
    // }); 

    this.eligibilityDetails = this.http.get(this.planEligUrl).subscribe((res) => {
      this.elgDetResponse = res && res.questions;
      this.primaryQuesLength = res.questions.length;
      this.planEligibilityRes(res.questions);
    }); 
  }

  openModalWithComponent() {
    const initialState = {
      errContent: 'The applicant does not qualify for this insurance and you will not be able to submit this application'
    };
    
    this.bsModalRef = this.modalService.show(ModalContentComponent, {initialState});
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  openModalWithComponent1() {
    const initialState = {
      errContent: 'Please answer all medical questions'
    };

    this.bsModalRef = this.modalService.show(ModalContentComponent, {initialState});
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  planEligibilityRes(res :Array<any> ) {
    const d = {questions:res.map(d=>{
      return {...d,secondaryQuestions:d.secondaryQuestions.map(sec=>{return {...sec, answerValue: '' }})}
    })}
      
    const n =d.questions.map(d=>{ 
      return this.fb.group({
        prim: new FormControl(d.primaryQuestionTxt),
        primaryQuestionId: new FormControl(d.primaryQuestionId),
        answerTypeName: new FormControl(d.answerTypeName),
        quest: this.fb.array(this.createQuestionForm(d.secondaryQuestions))
      })
    });
    
    this.form = this.fb.group({
      qaArray: this.fb.array(n)
    });
  }

  createQuestionForm(secondaryQuestions) {
    const secQues = secondaryQuestions.map(control => {
      return new FormGroup({
        questionText: new FormControl(control.secondaryQuestionTxt),
        secondaryQuestionId: new FormControl(control.secondaryQuestionId),
        answerTypeName: new FormControl(control.answerTypeName),
        answerValue: new FormControl(control.answerValue, [customTrueValidator()])
      })
    })
    return secQues;
  }

  get Controls() {
    return this.form.get('qaArray');
  }

  log(event: boolean) {
    if (event == true) {
      this.ishowAccordion = true;
    } else {
      this.ishowAccordion = false;
    }
  }

  onChange() {
    this.openModalWithComponent();
  }

  gotoPrevious() {
    this.planEligibilityService.updatedBeginEnrollAccoState(true);
  }

  gotoNext() {
    if(this.form.valid) {
      this.healthHistoryService.updatedHealthHistoryAccoState(true);
     this.ishowAccordion = !this.ishowAccordion;
    } else {
      this.openModalWithComponent1();
    }
  }

  ngOnDestroy() {
    this.applicantDetailsSubscription.unsubscribe();
  }

}

export function customTrueValidator() : ValidatorFn{
  return (control: AbstractControl): {[key: string]: any} | null => {
      return control.value !== 'N'   ? {'invalid': true} : null;
    };
  }

  @Component({
    selector: 'modal-content',
    template: `
      <div class="modal-body">
      <button type="button" class="close pull-right" aria-label="Close" (click)="bsModalRef.hide()">
        <span><img src="../../../../../assets/images/Close Circle.svg" alt="Warning"></span>
      </button>
        <span><img src="../../../../../assets/images/Path 62.svg" alt="Warning"></span>
        <p class="modal-errcontent">{{errContent}}</p>
      </div>
    `,
    styleUrls: ['./plan-eligibility.component.scss']
  })
  
  export class ModalContentComponent implements OnInit {
    title: string;
    closeBtnName: string;
    errContent: string;
    errMessage: string;
    constructor(public bsModalRef: BsModalRef) {}
  
    ngOnInit() {
     
    }
  }

  


