import { TestBed } from '@angular/core/testing';

import { AppConfigService } from './app-config.service';
import { HttpClient } from '@angular/common/http';

let httpClientSpy: { post: jasmine.Spy };

describe('AppConfigService', () => {
  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    TestBed.configureTestingModule({
      providers: [{ provide: HttpClient, useValue: httpClientSpy }]
    })
  });

  it('should be created', () => {
    const service: AppConfigService = TestBed.get(AppConfigService);
    expect(service).toBeTruthy();
  });
});
