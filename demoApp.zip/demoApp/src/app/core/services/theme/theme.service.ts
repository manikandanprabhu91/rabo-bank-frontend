import { Injectable } from '@angular/core';
import { Theme, base } from './theme';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  private active: Theme = base;
  private availablethemes: Theme[]=[base];

  constructor() { }

  getAvailableThemes(): Theme[] {
    return this.availablethemes;
  }

  getActiveTheme(): Theme {
    return this.active;
  }

  setDefaultTheme(): void {
    this.setActiveTheme(base );
  }

  setActiveTheme(theme: Theme): void {
    this.active = theme;
    Object.keys(this.active.properties).forEach(property => {
      document.documentElement.style.setProperty(property, this.active.properties[property]);
    });
  }
  
}
