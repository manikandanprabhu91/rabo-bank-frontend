import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReplacementQuestionsService {

  constructor() { }
  private replaceQuesaccoShowHide = new BehaviorSubject<boolean>(false);
  data = this.replaceQuesaccoShowHide.asObservable();

  updatedreplaceQuesAccoState(data: boolean){
    this.replaceQuesaccoShowHide.next(data);
  }
}
