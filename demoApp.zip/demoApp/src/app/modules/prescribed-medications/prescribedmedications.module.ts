import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PrescribedMedicationsRoutingModule } from './prescribedmedications-routing.module';
import { PrescribedMedicationsComponent, ModalContentComponent } from './components/prescribed-medications/prescribed-medications.component';

@NgModule({
  declarations: [PrescribedMedicationsComponent, ModalContentComponent],
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    ButtonsModule.forRoot(),
    ModalModule.forRoot(),
    PrescribedMedicationsRoutingModule
  ],
  entryComponents: [ModalContentComponent],
  exports:[PrescribedMedicationsComponent]
})
export class PrescribedMedicationsModule { }
