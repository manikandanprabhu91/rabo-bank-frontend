import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule, AccordionComponent } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';

import { EnrollComponent } from './enroll.component';
import { PlanEligibilityModule } from './../../../plan-eligibility/plan-eligibility.module';
import { HealthHistoryModule } from './../../../health-history/health-history.module';
import { DemogrphicModule } from './../../../demogrphic/demogrphic.module';
import { PlanBenefitsModule } from './../../../plan-benefits/plan-benefits.module';
import { PaymentInformationModule } from './../../../payment-information/payment-information.module';
import { ReviewModule } from './../../../review-plan/review.module';
import { CoreModule } from './../../../../core/core.module';

describe('EnrollComponent', () => {
  let component: EnrollComponent;
  let fixture: ComponentFixture<EnrollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        EnrollComponent
      ],
      imports: [ 
        ReactiveFormsModule,
        BrowserAnimationsModule,
        BsDatepickerModule.forRoot(),
        AccordionModule.forRoot(),
        ButtonsModule.forRoot(),
        PlanEligibilityModule,
        DemogrphicModule,
        HealthHistoryModule,
        PlanBenefitsModule,
        PaymentInformationModule,
        ReviewModule,
        CoreModule
       ],
       providers: [AccordionComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnrollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
