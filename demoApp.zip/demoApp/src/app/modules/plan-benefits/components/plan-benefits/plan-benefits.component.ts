import { Component, OnInit } from '@angular/core';
import { PlanBenifitsService } from './../../services/plan-benifits.service';
import { ReplacementQuestionsService } from './../../../replacement-questions/services/replacement-questions.service';
import { PaymentInformationService } from './../../../payment-information/services/payment-information.service';

@Component({
  selector: 'app-plan-benefits',
  templateUrl: './plan-benefits.component.html',
  styleUrls: ['./plan-benefits.component.scss']
})
export class PlanBenefitsComponent implements OnInit {
  isContentOpen: boolean;
  openPlanBenefAccordion: boolean;
  customClass = 'customClass';
  constructor(private planBenifitsService: PlanBenifitsService,
    private replacementQuestionsService: ReplacementQuestionsService,
    private paymentInformationService: PaymentInformationService) { }

  ngOnInit() {
    this.planBenifitsService.data2.subscribe(
      res => this.openPlanBenefAccordion = res
    )

    this.paymentInformationService.data2.subscribe(
      res => this.openPlanBenefAccordion = res
    )
  }

  log(event: boolean) {
    if(event == true) {
        this.openPlanBenefAccordion = true;
    } else {
        this.openPlanBenefAccordion = false;
    }
  }

  gotoPrevious() {
    this.planBenifitsService.updatedplanBenefaccoShowHideAccoState(true);
  }

  gotoNext() {
    this.paymentInformationService.updatedHealthHistoryAccoState(true);
    this.openPlanBenefAccordion = !this.openPlanBenefAccordion;
  }
}
