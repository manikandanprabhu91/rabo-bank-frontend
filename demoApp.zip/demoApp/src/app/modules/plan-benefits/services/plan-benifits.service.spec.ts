import { TestBed } from '@angular/core/testing';

import { PlanBenifitsService } from './plan-benifits.service';

describe('PlanBenifitsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlanBenifitsService = TestBed.get(PlanBenifitsService);
    expect(service).toBeTruthy();
  });
});
