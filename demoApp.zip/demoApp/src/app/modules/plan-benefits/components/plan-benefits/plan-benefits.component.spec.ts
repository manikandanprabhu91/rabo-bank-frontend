import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule, AccordionComponent } from 'ngx-bootstrap/accordion';
import { PlanBenefitsComponent } from './plan-benefits.component';

describe('PlanBenefitsComponent', () => {
  let component: PlanBenefitsComponent;
  let fixture: ComponentFixture<PlanBenefitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanBenefitsComponent ],
      imports: [
        BrowserAnimationsModule,
        FormsModule, 
        ReactiveFormsModule,
        ButtonsModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AccordionModule.forRoot()
      ],
      providers: [ AccordionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
