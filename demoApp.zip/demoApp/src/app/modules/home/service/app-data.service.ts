import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppDataService {

  constructor(private http: HttpClient) { }

  fetchTitle(jData) {
    return jData.title;
  }

  fetchCountries(jData) {
    return jData.countries;
  }
  
  fetchFlex(jData) {
    return jData.flex;
  }

  fetchDisclosure(jData) {
    return jData.disclosure;
  }

  fetchHospitalFlexData(jData) {
    return jData.flexplan;
  }

  fetchAboutUs(jData) {
    return jData.aboutus;
  }

  fetchPlans(jData){
    return jData.plans;
  }
}
