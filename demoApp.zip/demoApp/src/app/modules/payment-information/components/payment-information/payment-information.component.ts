import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, Validators, FormControl } from '@angular/forms';

import { PaymentInformationService } from './../../services/payment-information.service';
import { ReviewPlanService } from './../../../review-plan/services/review-plan.service';

@Component({
  selector: 'app-payment-information',
  templateUrl: './payment-information.component.html',
  styleUrls: ['./payment-information.component.scss']
})
export class PaymentInformationComponent implements OnInit {
  paymentInfo : FormGroup;
  isContentOpen: boolean;
  toggleDraft: any;
  openPaymentInfoAccordion: boolean;
  customClass = 'customClass';
  constructor(private fb: FormBuilder, private paymentInformationService: PaymentInformationService,
    private reviewPlanService: ReviewPlanService) { }

  ngOnInit() {
    this.paymentInfo = this.fb.group({
      checkSave: ['', [Validators.required]],
      draftDate: ['',[Validators.required]],
      reAccNum: ['',[Validators.required]],
      accNum: ['',[Validators.required]],
      proposedInsure: ['',[Validators.required , Validators.pattern(/[aA-zZ0-9\d\-_.,*()'\s]+$/)]],
      RouteNum: ['',[Validators.required]],
      FinInsName: ['',[Validators.required, Validators.pattern(/[aA-zZ0-9]$/)]]
      });
    this.paymentInformationService.data2.subscribe(
      res => this.openPaymentInfoAccordion = res
    )

    this.reviewPlanService.data2.subscribe(
      res => this.openPaymentInfoAccordion = res
    )
  }

  get checkSave() { return this.paymentInfo.get('checkSave'); }
  get draftDate() { return this.paymentInfo.get('draftDate'); }
  get reAccNum() { return this.paymentInfo.get('reAccNum'); }
  get accNum() { return this.paymentInfo.get('accNum'); }
  get FinInsName() { return this.paymentInfo.get('FinInsName'); }
  get RouteNum() { return this.paymentInfo.get('RouteNum'); }
  get proposedInsure() { return this.paymentInfo.get('proposedInsure'); }
  log(event: boolean) {
    if(event == true) {
        this.openPaymentInfoAccordion = true;
    } else {
        this.openPaymentInfoAccordion = false;
    }
  }

  gotoPrevious() {
    this.paymentInformationService.updatedHealthHistoryAccoState(true);
  }

  gotoNext() {
    this.reviewPlanService.updatedreviewPlansaccoShowHideAccoState(true);
    this.openPaymentInfoAccordion = !this.openPaymentInfoAccordion;
  }
}
