import { TestBed } from '@angular/core/testing';

import { PrescribedMedicationsService } from './prescribed-medications.service';

describe('PrescribedMedicationsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrescribedMedicationsService = TestBed.get(PrescribedMedicationsService);
    expect(service).toBeTruthy();
  });
});
