import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SocialSecurityMaskPipe } from './social-security-mask/social-security-mask.pipe';

@NgModule({
  declarations: [
    SocialSecurityMaskPipe
  ],
  imports: [
    CommonModule
  ],
  exports: [
    SocialSecurityMaskPipe
  ]
})
export class ApplicationPipesModule { }
