import { CoreModule } from '../../core/core.module';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { LandingComponent } from './components/landing/landing.component';
import { RateQuoteComponent } from './components/rate-quote/rate-quote.component';


@NgModule({
  declarations: [LandingComponent, RateQuoteComponent],
  imports: [
    CoreModule,
    CommonModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule

  ],
  exports: [LandingComponent, RateQuoteComponent

  ]
})
export class HomeModule { }
