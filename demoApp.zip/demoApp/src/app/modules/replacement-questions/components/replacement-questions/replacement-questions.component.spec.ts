import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplacementQuestionsComponent } from './replacement-questions.component';

describe('ReplacementQuestionsComponent', () => {
  let component: ReplacementQuestionsComponent;
  let fixture: ComponentFixture<ReplacementQuestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReplacementQuestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplacementQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
