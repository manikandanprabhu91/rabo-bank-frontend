import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, FormArray, FormControl } from '@angular/forms';
import { HealthHistoryService } from './../../services/health-history.service';
import { PlanEligibilityService } from './../../../plan-eligibility/services/plan-eligibility.service';
import { PrescribedMedicationsService } from './../../../prescribed-medications/services/prescribed-medications.service';

@Component({
  selector: 'app-health-history',
  templateUrl: './health-history.component.html',
  styleUrls: ['./health-history.component.scss']
})
export class HealthHistoryComponent implements OnInit {

  healthHistoryForm: FormGroup;
  physicianInfoForm: FormGroup;
  openHealthHistoryAccordion: boolean;
  customClass = 'customClass';
  addAdditionalInfo;
  constructor(private fb: FormBuilder,
     private healthHistoryService: HealthHistoryService,
     private planEligibilityService: PlanEligibilityService,
     private prescribedMedicationsService: PrescribedMedicationsService) { }

  ngOnInit() {
    this.healthHistoryService.show()
  
    this.healthHistoryForm = this.fb.group({
      prescribedMedications: this.fb.array([
          this.fb.group({
            prescribedMedline1: [],
            prescribedMedline2: [],
            prescribedMedline3: [],
            prescribedMedline4: [],
            prescribedMedline5: [],
            prescribedMedline6: []
          })
       ]),
       reasonForMedications: this.fb.array([
        this.fb.group({
          reasonForMedline1: [],
          reasonForMedline2: [],
          reasonForMedline3: [],
          reasonForMedline4: [],
          reasonForMedline5: [],
          reasonForMedline6: []
        })
       ])
    })

    this.physicianInfoForm = this.fb.group({
        primaryPhysician: [],
        physicianOfficeName: [],
        phone: [],
        city: [],
        state: [],
        seenInPast24months: [],
        speciality: [],
        reasonForSeeing: []
    })

    this.healthHistoryService.data2.subscribe(
      data1 => this.openHealthHistoryAccordion = data1
    )

    this.prescribedMedicationsService.data.subscribe(
      res => this.openHealthHistoryAccordion = res
    )
  }

  accOpenChange(event: boolean) {
    if(event == true) {
        this.openHealthHistoryAccordion = true;
    } else {
        this.openHealthHistoryAccordion = false;
    }
  }

  add() {
    this.addAdditionalInfo = this.healthHistoryForm.get('prescribedMedications') as FormArray;
    this.addAdditionalInfo.push(new FormControl(''))
  }

  gotoPrevious() {
    this.healthHistoryService.updatedHealthHistoryAccoState(true);
  }

  gotoNext() {
    this.prescribedMedicationsService.updatedPrescribedMedAccoState(true);
    this.openHealthHistoryAccordion = !this.openHealthHistoryAccordion;
  }

}
