import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApplicantDetailsService {

  constructor() { }

  private accoShowHide = new BehaviorSubject<boolean>(false);
  data = this.accoShowHide.asObservable();

  updatedAccoState(data: boolean){
    this.accoShowHide.next(data);
  }
}
