import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { ModalModule } from 'ngx-bootstrap/modal';

import { PlanEligibilityRoutingModule } from './plan-eligibility-routing.module';
import { PlanEligibilityComponent, ModalContentComponent } from './components/plan-eligibility/plan-eligibility.component';

@NgModule({
  declarations: [ PlanEligibilityComponent, ModalContentComponent ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    ButtonsModule.forRoot(),
    ModalModule.forRoot(),
    PlanEligibilityRoutingModule
  ],
  entryComponents: [ModalContentComponent],
  exports:[ PlanEligibilityComponent ]
})
export class PlanEligibilityModule { }
