import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CoreModule } from '../../../../core/core.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { LandingComponent } from './landing.component';
import { RateQuoteComponent } from '../rate-quote/rate-quote.component';
import { AppDataService } from '../../service/app-data.service';

describe('LandingComponent', () => {
  let component: LandingComponent;
  let fixture: ComponentFixture<LandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CoreModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        BrowserAnimationsModule,
        BsDatepickerModule.forRoot()
      ],
      declarations: [LandingComponent, RateQuoteComponent],
      providers: [AppDataService]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('landing page should create', () => {
    expect(component).toBeTruthy();
  });

  it('landingPage should be invalid', () => {
    expect(component.landingPage.valid).toBeFalsy();
  });

  it('state should be valid', () => {
    let errors = {};
    let state = component.landingPage.get('state');
    expect(state.valid).toBeFalsy();

    errors = state.errors || {}
    expect(errors['required']).toBeTruthy();

    state.setValue('Florida');
    errors = state.errors || {}
    expect(errors['required']).toBeFalsy();
  })

  it('dateofBirth should be valid', () => {
    let errors = {};
    let dateofBirth = component.landingPage.get('dateofBirth');
    expect(dateofBirth.valid).toBeFalsy();

    errors = dateofBirth.errors || {}
    expect(errors['required']).toBeTruthy();

    dateofBirth.setValue('10/07/2001');
    errors = dateofBirth.errors || {}
    expect(errors['required']).toBeFalsy();
  })
});
