import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidationErrors, ValidatorFn, FormControl } from '@angular/forms';
import { AbstractControl } from '@angular/forms';
// import moment from 'moment';
import { DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';
import { HttpClientService } from '../../../../core/http/http-client.service';
import { AppDataService } from '../../service/app-data.service';
import { ThemeService } from '../../../../core/services/theme/theme.service';
import { RateQuotePlanDataService } from './../../../../shared/services/rate-quote-plan-data.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit, AfterViewInit {
  birthDateValue: Date;
  effectiveDateValue: Date;
  dateCustomClasses: DatepickerDateCustomClasses[];
  landingPage: FormGroup;
  showRateQuote: boolean = false;
  toggle;
  content;
  title;
  flexData;
  disclosure;
  flexPlan;
  aboutContent;
  jsonData;
  plans;
  disableDates;
  isDisabled = false;
  maxDate;
  changedDate;
  onKeyDown;
  getRate;
  @ViewChild('ref') refer: ElementRef;
  public url = './assets/data/content.json';
  constructor(private rateQuotePlanDataService: RateQuotePlanDataService, private elem: ElementRef, private fb: FormBuilder, private appData: AppDataService, private httpClient: HttpClientService, private themeservice: ThemeService) {
    //this.landingPage.setValidators(this.minimumAge(18));
    this.birthDateValue = new Date();
    console.log(this.birthDateValue);
    this.birthDateValue.setFullYear( this.birthDateValue.getFullYear() - 65 );
    this.birthDateValue.setDate( this.birthDateValue.getDate());
    console.log(this.birthDateValue.getDate());
    // Effective Date validations
    this.effectiveDateValue = new Date();
    this.maxDate= new Date(new Date().setMonth(new Date().getMonth() + 3))
    this.disableDates = this.effectiveDateValue.getDate();
    console.log(this.disableDates);
    if(this.disableDates == 29)
    {
      this.effectiveDateValue.setMonth(this.effectiveDateValue.getMonth()+1, 1);
    }
    if(this.disableDates == 30)
    {
      this.effectiveDateValue.setMonth(this.effectiveDateValue.getMonth()+1, 1);
    }
    if(this.disableDates == 31)
    {
      this.effectiveDateValue.setMonth(this.effectiveDateValue.getMonth()+1, 1);
    }

  }

  ngOnInit() {
    window.addEventListener('keydown', this.onKeyDown, true);
    document.addEventListener('effectiveDateElement', event => event.preventDefault());
    
    this.themeservice.setDefaultTheme();
    this.landingPage = this.fb.group({
    state: ['', [Validators.required]],
    dateofBirth: ['', [Validators.required, this.forbiddenDoBValidator]],
    effectiveDate: ['', [Validators.required, this.forbiddenEffectiveDateValidator]]
    });

    this.jsonData = this.httpClient.get(this.url).subscribe((res) => {
      this.title = this.appData.fetchTitle(res);
      this.content = this.appData.fetchCountries(res);
      this.flexData = this.appData.fetchFlex(res);
      this.disclosure =this.appData.fetchDisclosure(res);
      this.flexPlan = this.appData.fetchHospitalFlexData(res);
      this.aboutContent = this.appData.fetchAboutUs(res);
      this.plans = this.appData.fetchPlans(res);
      return res;
    });

    this.landingPage.get('effectiveDate').valueChanges.subscribe(
      data => {
        this.updateEffectiveDate(data);
        //this.openModalWithComponent();
      }
    )
  }

  get state() { return this.landingPage.get('state'); }
  get dateofBirth() { return this.landingPage.get('dateofBirth'); }
  get effectiveDate() { return this.landingPage.get('effectiveDate'); }

  ngAfterViewInit() {
     console.log(this.refer.nativeElement.value);
  }
  changedValue(ref)
  {
    console.log('test' + ref);
    console.log(this.effectiveDateValue);
    console.log(this.refer.nativeElement.value);
    this.changedDate = this.refer.nativeElement.value;
    // if(this.changedDate == 29)
    //  {
    //    console.log("its 29");
    //  }
  }
  
  updateQuoteData() {
    this.rateQuotePlanDataService.changeState(this.state.value);
    this.rateQuotePlanDataService.changeDoB(this.dateofBirth.value);
    this.rateQuotePlanDataService.changeEffectiveDate(this.effectiveDate.value);
  }
  
  showRateQuoteContent() {
    this.showRateQuote = true;
    this.updateQuoteData();
  }
  showRateQuoteContentGet()
  {
    this.showRateQuote = false;
  }

  forbiddenNameValidator(nameRe: RegExp): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      const forbidden = nameRe.test(control.value);
      return forbidden ? { 'forbiddenName': {value: control.value}} : null;
    };
  }

  forbiddenDoBValidator(control: AbstractControl) {
      const dob = new Date(control.value);
      const todayDate = new Date();
      let age = todayDate.getFullYear() - dob.getFullYear();
      if (age < 0) {
        age = 0;
      } else {
        const month = todayDate.getMonth() - dob.getMonth();
        if (month < 0 || (month === 0 && todayDate.getDate() < dob.getDate())) {
            age = age - 1;
        }
      }
      if (age < 18) {
        return { minAgeNotMeet: true }
      } else {
        return null;
      }
  }

  forbiddenEffectiveDateValidator(control: AbstractControl) {

    if (!control.value) {
      // console.log('empty String');
      return null;
    }
    const effectiveDate = new Date(control.value);
    const todayDate = new Date();
    const dayDifference =  Math.ceil((effectiveDate.valueOf() - todayDate.valueOf()) / (24 * 60 * 60 * 1000));
  
    if (dayDifference > 90) {
      return { maxEffectiveDateNotMeet: true }
    } else if( dayDifference < 0) {
      return { minEffectiveDateNotMeet: true }
    } else {
      return null;
    }
}


  calculateAge(dob: Date): number{
    const todayDate = new Date();
    let age = todayDate.getFullYear() - dob.getFullYear();
    if (age < 0) {
      age = 0;
    } else {
      const month = todayDate.getMonth() - dob.getMonth();
      if (month < 0 || (month === 0 && todayDate.getDate() < dob.getDate())) {
          age = age - 1;
      }
    }
    return age;
  }

  updateEffectiveDate(inputDate: number){
    let inputEffectiveDate = new Date(inputDate);
    const day = inputEffectiveDate.getDate();
    const month = inputEffectiveDate.getMonth();
    const year = inputEffectiveDate.getFullYear();
    if ( day === 29 || day === 30 || day === 31) {
      inputEffectiveDate.setDate(1);
      if(month === 12) {
        inputEffectiveDate.setMonth(1);
        inputEffectiveDate.setFullYear(year + 1);
      } else {
        inputEffectiveDate.setMonth(month + 1);
      }
      this.landingPage.patchValue({
        effectiveDate: inputEffectiveDate
      });
      //const todayDate = new Date();
      //const dayDifference =  Math.ceil((effectiveDate.valueOf() - todayDate.valueOf()) / (24 * 60 * 60 * 1000));      
    }
    
  }

}
