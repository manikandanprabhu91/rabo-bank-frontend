import { SocialSecurityMaskPipe } from './social-security-mask.pipe';

describe('SocialSecurityPipe', () => {
  it('create an instance', () => {
    const pipe = new SocialSecurityMaskPipe();
    expect(pipe).toBeTruthy();
  });
});
