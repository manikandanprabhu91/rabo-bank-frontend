import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';

import { EnrollmentRoutingModule } from './enrollment-routing.module';
import { PlanEligibilityModule } from './../plan-eligibility/plan-eligibility.module';
import { HealthHistoryModule } from './../health-history/health-history.module';
import { DemogrphicModule } from '../demogrphic/demogrphic.module';
import { PlanBenefitsModule } from '../plan-benefits/plan-benefits.module';
import { PaymentInformationModule } from '../payment-information/payment-information.module';
import { PrescribedMedicationsModule } from '../prescribed-medications/prescribedmedications.module';
import { ReplacementQuestionsModule } from '../replacement-questions/replacement-questions.module';
import { ReviewModule } from '../review-plan/review.module';
import { CoreModule } from '../../core/core.module';

import { EnrollComponent } from './components/enroll/enroll.component';

@NgModule({
  declarations: [EnrollComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AccordionModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ButtonsModule.forRoot(),
    EnrollmentRoutingModule,
    PlanEligibilityModule,
    HealthHistoryModule,
    DemogrphicModule,
    PlanBenefitsModule,
    PaymentInformationModule,
    ReviewModule,
    PrescribedMedicationsModule,
    ReplacementQuestionsModule,
    CoreModule
  ],
  exports: [ EnrollComponent ]
})
export class EnrollmentModule { }
