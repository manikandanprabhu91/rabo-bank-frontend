import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AddHeaderInterceptor } from './../../core/interceptors/header-interceptor/header-interceptor';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { DemogrphicRoutingModule } from './demogrphic-routing.module';
import { ApplicantDetailsComponent } from './components/applicant-details/applicant-details.component';
import { ApplicationPipesModule } from '../../shared/pipes/application-pipes.module';
import { ModalModule } from 'ngx-bootstrap/modal';

@NgModule({
  declarations: [ApplicantDetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    ButtonsModule.forRoot(),
    AccordionModule.forRoot(),
    DemogrphicRoutingModule,
    ApplicationPipesModule,
    ModalModule.forRoot()
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AddHeaderInterceptor,
    multi: true,
  }],
  exports: [ ApplicantDetailsComponent ]
})
export class DemogrphicModule { }
