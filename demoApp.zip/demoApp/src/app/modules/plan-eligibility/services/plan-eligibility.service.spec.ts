import { TestBed } from '@angular/core/testing';

import { PlanEligibilityService } from './plan-eligibility.service';

describe('PlanEligibilityService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlanEligibilityService = TestBed.get(PlanEligibilityService);
    expect(service).toBeTruthy();
  });
});
