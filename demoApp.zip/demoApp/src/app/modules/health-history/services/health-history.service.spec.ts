import { TestBed } from '@angular/core/testing';

import { HealthHistoryService } from './health-history.service';

describe('HealthHistoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HealthHistoryService = TestBed.get(HealthHistoryService);
    expect(service).toBeTruthy();
  });
});
