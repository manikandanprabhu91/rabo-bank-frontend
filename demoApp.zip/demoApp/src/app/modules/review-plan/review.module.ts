import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { ReviewRoutingModule } from './review-routing.module';
import { ReviewPlanComponent } from './components/review-plan/review-plan.component';

@NgModule({
  declarations: [ReviewPlanComponent],
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    ButtonsModule.forRoot(),
    ReviewRoutingModule
  ],
  exports:[ ReviewPlanComponent ]
})
export class ReviewModule { }
