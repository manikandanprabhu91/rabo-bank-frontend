import {
    HttpEvent,
    HttpInterceptor,
    HttpHandler,
    HttpRequest
  } from '@angular/common/http';
  import { Observable } from 'rxjs';
  
  export class AddHeaderInterceptor implements HttpInterceptor {

    private token = 'AAIkMTIzNmFmNGItZGIwYy00YzYwLWFhMDUtZDIwNWVkM2MyNWIyJiMlOCgzNlpdWlT6bAenD_cqIU4ePxmaoOXLVRYjnIzX6ltMXEwt14lg2yIxCWpV_PBLO5vlEdKPgprdE1bMyy8GaOCG4HrqN0DRIsNoyvQnGnvtbtrzozbCyXlLM1HGD6tNAU2iCfI1oA4PbfWCqA'
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      // Clone the request to add the new header
      const clonedRequest = req.clone({ 
        headers: req.headers.set('Content-Type', 'application/json')
       .set('Authorization', `Bearer ${this.token}`)
    });
  
      // Pass the cloned request instead of the original request to the next handle
      return next.handle(clonedRequest);
    }
  }