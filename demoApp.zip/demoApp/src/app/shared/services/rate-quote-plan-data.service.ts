import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
// import { Plan } from './../models/plan';
// import { QuoteRequest } from './../models/quote-request';
// import { Quote } from 'src/app/modules/home/components/rate-quote/quote-model';

@Injectable({
  providedIn: 'root'
})
export class RateQuotePlanDataService {

  // private quoteRequestSource = new BehaviorSubject(new QuoteRequest());
  // private planSource = new BehaviorSubject(new Plan());
  // currentPlan = this.planSource.asObservable();
  // currentQuoteRequest = this.quoteRequestSource.asObservable();

  private stateSource = new BehaviorSubject('');
  private effectiveDateSource = new BehaviorSubject('');
  private dobSource = new BehaviorSubject('');
  currentState = this.stateSource.asObservable();
  currentEffectiveDate = this.effectiveDateSource.asObservable();
  currentDoB = this.dobSource.asObservable();

  constructor() { }

  // changeQuoteRequest(quoterequest: QuoteRequest) {
  //   this.quoteRequestSource.next(quoterequest);
  // }

  // changePlan(plan: Plan) {
  //   this.planSource.next(plan);
  // }

  changeState(state: string) {
    this.stateSource.next(state);
    // this.currentState.subscribe( state => tempState = state);
    // console.log('current state: ' + tempState);
    sessionStorage.setItem('quoteMemberState', state);
  }

  changeEffectiveDate(effectiveDate: string) {
    this.effectiveDateSource.next(effectiveDate);
    // this.currentEffectiveDate.subscribe( date => console.log('Effective Date: ' + date));
    sessionStorage.setItem('quoteEffectiveDate', effectiveDate);
  }

  changeDoB(dob: string) {
    this.dobSource.next(dob);
    // this.currentDoB.subscribe( date => console.log('DoB: ' + date));
    sessionStorage.setItem('quoteMemberDoB', dob);
    // console.log('Current dob: ' + this.currentDoB);
  }


}


