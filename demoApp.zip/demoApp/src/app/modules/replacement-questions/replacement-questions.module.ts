import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { ReplacementQuestionsRoutingModule } from './../replacement-questions/replacementquestions-routing.module';
import { ReplacementQuestionsComponent } from './components/replacement-questions/replacement-questions.component';


@NgModule({
  declarations: [ReplacementQuestionsComponent],
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    ButtonsModule.forRoot(),
    ReplacementQuestionsRoutingModule
  ],
  exports:[ ReplacementQuestionsComponent ]
})
export class ReplacementQuestionsModule { }
