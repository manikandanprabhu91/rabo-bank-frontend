import { Component, OnInit } from '@angular/core';
import { ReviewPlanService } from './../../../review-plan/services/review-plan.service';

@Component({
  selector: 'app-review-plan',
  templateUrl: './review-plan.component.html',
  styleUrls: ['./review-plan.component.scss']
})
export class ReviewPlanComponent implements OnInit {
  isContentOpen: boolean;
  openReviewPlanAccordion: boolean;
  customClass = 'customClass';
  constructor(private reviewPlanService: ReviewPlanService) { }

  ngOnInit() {
    this.reviewPlanService.data2.subscribe(
      res => this.openReviewPlanAccordion = res
    )
  }

  log1(event: boolean) {
    if(event == true) {
        this.openReviewPlanAccordion = true;
    } else {
        this.openReviewPlanAccordion = false;
    }
  }

  gotoPrevious() {
    this.reviewPlanService.updatedreviewPlansaccoShowHideAccoState(true);
  }

}
