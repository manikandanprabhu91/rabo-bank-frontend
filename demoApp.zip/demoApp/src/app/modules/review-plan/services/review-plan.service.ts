import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReviewPlanService {

  constructor() { }

  private reviewPlansaccoShowHide = new BehaviorSubject<boolean>(false);
  data2 = this.reviewPlansaccoShowHide.asObservable();

  updatedreviewPlansaccoShowHideAccoState(data: boolean){
    this.reviewPlansaccoShowHide.next(data);
  }
}
