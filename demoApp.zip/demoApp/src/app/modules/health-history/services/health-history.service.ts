import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HealthHistoryService {

  constructor() { }

  private healthHistoryaccoShowHide = new BehaviorSubject<boolean>(false);
  data2 = this.healthHistoryaccoShowHide.asObservable();

    updatedHealthHistoryAccoState(data: boolean){
      this.healthHistoryaccoShowHide.next(data);
    }
    show(){
      alert('sss')
    }
}
