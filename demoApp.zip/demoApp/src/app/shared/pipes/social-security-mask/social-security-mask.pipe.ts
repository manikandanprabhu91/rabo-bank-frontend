import { Pipe, PipeTransform } from '@angular/core';
import { IfStmt } from '@angular/compiler';
import { isUndefined } from 'ngx-bootstrap/chronos/utils/type-checks';

@Pipe({
  name: 'socialSecurityMask'
})
export class SocialSecurityMaskPipe implements PipeTransform {

  transform(value: string, showMask: boolean): string {
    if (showMask && value.match('^[0-9]{9}$')){
      return 'XXX-XX-' + value.substr(value.length - 4);
    }
    return value;
  }
  // transform(value: string, maskData: boolean): string {
  //   console.log(value);
  //   if(maskData && value.match('^[0-9]{9}$')) {
  //       return 'XXX-XX-' + value.substr(value.length - 4);
  //   }
  //   return value;
  // }
}
