import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { PrescribedMedicationsService } from './../../services/prescribed-medications.service';
import { ReplacementQuestionsService } from './../../../replacement-questions/services/replacement-questions.service';

@Component({
  selector: 'app-prescribed-medications',
  templateUrl: './prescribed-medications.component.html',
  styleUrls: ['./prescribed-medications.component.scss']
})
export class PrescribedMedicationsComponent implements OnInit {
  healthHistoryForm: FormGroup;
  openPresMedAccordion: boolean;
  items: any;
  modalRef: BsModalRef;
  customClass = 'customClass';
  bsModalRef: BsModalRef;
  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    private prescribedMedicationsService: PrescribedMedicationsService,
    private replacementQuestionsService: ReplacementQuestionsService) { }

  ngOnInit() {
    this.prescribedMedicationsService.data.subscribe(
      res => this.openPresMedAccordion = res
    )

    this.replacementQuestionsService.data.subscribe(
      data => this.openPresMedAccordion = data
    )
    this.healthHistoryForm = this.fb.group({
      prescribedMed: this.fb.array([
        this.fb.group({
          prescribedMedications: [],
          reasonForMedications: [],
        }),
        this.fb.group({
          prescribedMedications: [],
          reasonForMedications: [],
        }),
        this.fb.group({
          prescribedMedications: [],
          reasonForMedications: [],
        }),
        this.fb.group({
          prescribedMedications: [],
          reasonForMedications: [],
        }),
        this.fb.group({
          prescribedMedications: [],
          reasonForMedications: [],
        })
      ])
    })
  }

  openModalWithComponent() {
    const initialState = {
      errContent: 'You told us you are taking a medication, please tell us why you are taking this medication',
    };
    this.bsModalRef = this.modalService.show(ModalContentComponent, {initialState});
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  addItem(): void {
    this.items = this.healthHistoryForm.get('prescribedMed') as FormArray;
    this.items.push(
      this.fb.group({
        prescribedMedications: [],
        reasonForMedications: [],
      })
    );
  }

  OpenChange(event: boolean) {
    if (event == true) {
      this.openPresMedAccordion = true;
    } else {
      this.openPresMedAccordion = false;
    }
  }

  

  gotoPrevious() {
    this.prescribedMedicationsService.updatedPrescribedMedAccoState(true);
  }

  gotoNext() {
    if(this.healthHistoryForm.valid) {
      this.replacementQuestionsService.updatedreplaceQuesAccoState(true);
      this.openPresMedAccordion = !this.openPresMedAccordion;
    } else {
      this.openModalWithComponent();
    }
  }

}

@Component({
  selector: 'modal-content',
  template: `
    <div class="modal-body">
    <button type="button" class="close pull-right" aria-label="Close" (click)="bsModalRef.hide()">
      <span class="err-content" aria-hidden="true">&times;</span>
    </button>
      <p class="err-content">{{errContent}}</p>
    </div>
  `
})

export class ModalContentComponent implements OnInit {
  title: string;
  closeBtnName: string;
  errContent: string;
  errMessage: string;
  constructor(public bsModalRef: BsModalRef) {}

  ngOnInit() {
   
  }
}
