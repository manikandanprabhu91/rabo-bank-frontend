import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PrescribedMedicationsService {

  constructor() { }
  private PrescribedMedaccoShowHide = new BehaviorSubject<boolean>(false);
  data = this.PrescribedMedaccoShowHide.asObservable();

  updatedPrescribedMedAccoState(data: boolean){
    this.PrescribedMedaccoShowHide.next(data);
  }
}
