import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import {ThemeService} from '../../../../core/services/theme/theme.service';
import { Quote } from './quote-model';
@Component({
  selector: 'app-rate-quote',
  templateUrl: './rate-quote.component.html',
  styleUrls: ['./rate-quote.component.scss']
})
export class RateQuoteComponent implements OnInit {
  @Input() quote: Quote;
  
  constructor(private router: Router, private themeservice: ThemeService) { }

  ngOnInit() {
    this.themeservice.setDefaultTheme();    
  }
  onCustomAction() { 
    this.router.navigate(['/enroll'])
      .then(success => console.log('navigation success?' , success))
      .catch(console.error); 
  } 
}
