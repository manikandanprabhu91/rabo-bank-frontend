import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from '../app/modules/home/components/landing/landing.component';
import { EnrollComponent } from '../app/modules/enrollment/components/enroll/enroll.component';

const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'enroll',  component: EnrollComponent },
  { path: '**', component: LandingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot( routes,
    {
      enableTracing: false, // <-- debugging purposes only
      useHash: true
    })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
