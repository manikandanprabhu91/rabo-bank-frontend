import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule, AccordionComponent } from 'ngx-bootstrap/accordion';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { PlanEligibilityComponent } from './plan-eligibility.component';

describe('PlanEligibilityComponent', () => {
  let component: PlanEligibilityComponent;
  let fixture: ComponentFixture<PlanEligibilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanEligibilityComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        BsDatepickerModule.forRoot(),
        AccordionModule.forRoot(),
        ButtonsModule.forRoot()
      ],
      providers: [AccordionComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanEligibilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('log function should call', () => {
     component.log(true);
     component.ishowAccordion = true;
     component.log(false);
     component.ishowAccordion = false;
  })

  it('gotoPrevious function should call', () => {
    component.gotoPrevious();
  })

});
