import { TestBed } from '@angular/core/testing';

import { ReplacementQuestionsService } from './replacement-questions.service';

describe('ReplacementQuestionsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReplacementQuestionsService = TestBed.get(ReplacementQuestionsService);
    expect(service).toBeTruthy();
  });
});
